#!/bin/sh
# Installs the LazyContainers icons and launcher for the current user.
# Use PREFIX=/usr/share sudo ./install-icons.sh for a system-wide install.
set -e
PREFIX="${PREFIX:-$HOME/.local/share}"
cd "$(dirname "$0")"
for dir in hicolor/*/apps; do
  mkdir -p "$PREFIX/icons/$dir"
  cp "$dir"/* "$PREFIX/icons/$dir/"
done
mkdir -p "$PREFIX/applications"
cp lazycontainers.desktop "$PREFIX/applications/"
gtk-update-icon-cache -f -t "$PREFIX/icons/hicolor" 2>/dev/null || true
update-desktop-database "$PREFIX/applications" 2>/dev/null || true
echo "LazyContainers icons installed in $PREFIX"
